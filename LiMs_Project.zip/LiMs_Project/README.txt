LiMs Android Studio Project (demo)
----------------------------------
How to use:
1. Open this folder in Android Studio (File -> Open -> select LiMs_Project folder).
2. Let Gradle sync. You may be prompted to install Android SDK components if missing.
3. Build -> Build APK(s). APK will appear under app/build/outputs/apk/debug/app-debug.apk.
4. Install the APK on your Android device. Login credentials: admin / admin

Notes:
- This is a demo skeleton: local DB, Room, Retrofit and WorkManager stubs are included in gradle dependencies but not fully implemented in code.
- The ZXing scanner is integrated (library dependency). If you face runtime issues, open project in Android Studio and let it resolve.
