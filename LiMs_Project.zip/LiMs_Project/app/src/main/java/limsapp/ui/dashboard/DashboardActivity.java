package limsapp.ui.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import limsapp.R;
import limsapp.ui.scanner.ScannerActivity;

public class DashboardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Button scanBtn = findViewById(R.id.scanButton);
        scanBtn.setOnClickListener((View v) -> {
            Intent i = new Intent(this, ScannerActivity.class);
            startActivity(i);
        });
    }
}
